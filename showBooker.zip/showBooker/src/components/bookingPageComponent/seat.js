// const seats = [
//   {
//     row: 'A',
//     seats: [
//       { seatNumber: 1, isBooked: false },
//       { seatNumber: 2, isBooked: false },
//       { seatNumber: 3, isBooked: false },
//       { seatNumber: 4, isBooked: false },
//       { seatNumber: 5, isBooked: false },
//       { seatNumber: 6, isBooked: false },
//       { seatNumber: 7, isBooked: false },
//       { seatNumber: 8, isBooked: false },
//       { seatNumber: 9, isBooked: false },
//       { seatNumber: 10, isBooked: false },
//     ],
//   },
//   {
//     row: 'B',
//     seats: [
//       { seatNumber: 1, isBooked: false },
//       { seatNumber: 2, isBooked: false },
//       { seatNumber: 3, isBooked: false },
//       { seatNumber: 4, isBooked: false },
//       { seatNumber: 5, isBooked: false },
//       { seatNumber: 6, isBooked: false },
//       { seatNumber: 7, isBooked: false },
//       { seatNumber: 8, isBooked: false },
//       { seatNumber: 9, isBooked: false },
//       { seatNumber: 10, isBooked: false },
//     ],
//   },
//   {
//     row: 'C',
//     seats: [
//       { seatNumber: 1, isBooked: false },
//       { seatNumber: 2, isBooked: false },
//       { seatNumber: 3, isBooked: false },
//       { seatNumber: 4, isBooked: false },
//       { seatNumber: 5, isBooked: false },
//       { seatNumber: 6, isBooked: false },
//       { seatNumber: 7, isBooked: false },
//       { seatNumber: 8, isBooked: false },
//       { seatNumber: 9, isBooked: false },
//       { seatNumber: 10, isBooked: false },
//     ],
//   },
//   {
//     row: 'D',
//     seats: [
//       { seatNumber: 1, isBooked: false },
//       { seatNumber: 2, isBooked: false },
//       { seatNumber: 3, isBooked: false },
//       { seatNumber: 4, isBooked: false },
//       { seatNumber: 5, isBooked: false },
//       { seatNumber: 6, isBooked: false },
//       { seatNumber: 7, isBooked: false },
//       { seatNumber: 8, isBooked: false },
//       { seatNumber: 9, isBooked: false },
//       { seatNumber: 10, isBooked: false },
//     ],
//   },
//   {
//     row: 'E',
//     seats: [
//       { seatNumber: 1, isBooked: false },
//       { seatNumber: 2, isBooked: false },
//       { seatNumber: 3, isBooked: false },
//       { seatNumber: 4, isBooked: false },
//       { seatNumber: 5, isBooked: false },
//       { seatNumber: 6, isBooked: false },
//       { seatNumber: 7, isBooked: false },
//       { seatNumber: 8, isBooked: false },
//       { seatNumber: 9, isBooked: false },
//       { seatNumber: 10, isBooked: false },
//     ],
//   },
// ];

// export default seats;


const seats= {
  A: [
    { seatNumber: 1, isBooked: false },
    { seatNumber: 2, isBooked: false },
    { seatNumber: 3, isBooked: false },
    { seatNumber: 4, isBooked: false },
    { seatNumber: 5, isBooked: false },
    { seatNumber: 6, isBooked: false },
    { seatNumber: 7, isBooked: false },
    { seatNumber: 8, isBooked: false },
    { seatNumber: 9, isBooked: false },
    { seatNumber: 10, isBooked: false },
  ],
  B: [
    { seatNumber: 1, isBooked: false },
    { seatNumber: 2, isBooked: false },
    { seatNumber: 3, isBooked: false },
    { seatNumber: 4, isBooked: false },
    { seatNumber: 5, isBooked: false },
    { seatNumber: 6, isBooked: false },
    { seatNumber: 7, isBooked: false },
    { seatNumber: 8, isBooked: false },
    { seatNumber: 9, isBooked: false },
    { seatNumber: 10, isBooked: false },
  
  ],
  c:[
    { seatNumber: 1, isBooked: false },
    { seatNumber: 2, isBooked: false },
    { seatNumber: 3, isBooked: false },
    { seatNumber: 4, isBooked: false },
    { seatNumber: 5, isBooked: false },
    { seatNumber: 6, isBooked: false },
    { seatNumber: 7, isBooked: false },
    { seatNumber: 8, isBooked: false },
    { seatNumber: 9, isBooked: false },
    { seatNumber: 10, isBooked: false },
  
  ],
  D:[
    { seatNumber: 1, isBooked: false },
    { seatNumber: 2, isBooked: false },
    { seatNumber: 3, isBooked: false },
    { seatNumber: 4, isBooked: false },
    { seatNumber: 5, isBooked: false },
    { seatNumber: 6, isBooked: false },
    { seatNumber: 7, isBooked: false },
    { seatNumber: 8, isBooked: false },
    { seatNumber: 9, isBooked: false },
    { seatNumber: 10, isBooked: false },
  
  ],
  E:[
    { seatNumber: 1, isBooked: false },
    { seatNumber: 2, isBooked: false },
    { seatNumber: 3, isBooked: false },
    { seatNumber: 4, isBooked: false },
    { seatNumber: 5, isBooked: false },
    { seatNumber: 6, isBooked: false },
    { seatNumber: 7, isBooked: false },
    { seatNumber: 8, isBooked: false },
    { seatNumber: 9, isBooked: false },
    { seatNumber: 10, isBooked: false },
  
  ]

  // Add rows C, D, E here
}
export default seats

